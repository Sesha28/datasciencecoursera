﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TheFamily.Models;

namespace TheFamily.Controllers
{
    using Newtonsoft.Json;
    public partial class HomeController : Controller
    {
        static Random rand = new Random();
        /// <summary>
        /// url :/Home/GetStudents
        /// </summary>
        /// <returns></returns>
        public String GetStudents()
        {
            return
            JsonConvert.SerializeObject(
            Enumerable.Range(0, 2).Select(i =>
             {
                 return new
                 {
                     Name = "Name_" + i,
                     //Address = "Address_" + i,
                     id = i * 2,
                     Apps = Enumerable.Range(0, rand.Next(10) + 2).Select(i => "TheApp_" + i).ToList(),
                     Projects = Enumerable.Range(0, rand.Next(4) + 2).Select(i => "Project_" + i).ToList()
                 };
             }).ToArray(), Formatting.Indented);
        }
        /// <summary>
        /// url : /Home/GetApps
        /// </summary>
        /// <returns></returns>
        public String GetApps()
        {
            return
            JsonConvert.SerializeObject(
            Enumerable.Range(0, 10).Select(i =>
            {
                return new
                {
                    Name = "App_" + i,
                    //Address = "Address_" + i,
                    id = i * 2
                };
            }).ToArray(), Formatting.Indented);
        }
        public String GetDetails()
        {
            return
            JsonConvert.SerializeObject(new
            {
                Name = "Suraj",
                id = rand.Next(100),
                Mail = "Someone@somewhere.com",
                Mobile = 9876543210,
                Apps = Enumerable.Range(0, rand.Next(4) + 2).Select(i => "TheApp_" + i).ToList(),
                Projects = Enumerable.Range(0, rand.Next(4) + 2).Select(i => "Project_" + i).ToList()
            });
        }
        public String GetUserProjects()
        {
            return
            JsonConvert.SerializeObject(Enumerable.Range(0, 10).Select(i =>
            {
                return new
                {
                    Name = "Project_" + i,
                    id = i,
                };
            }));
        }
        public String GetProjectApps()
        {
            return
            JsonConvert.SerializeObject(Enumerable.Range(0, 10).Select(i =>
            {
                return new
                {
                    Name = "TheApp_" + i,
                    id = i,
                };
            }));
        }
        public string getAllApps()
        {
            return
            JsonConvert.SerializeObject(Enumerable.Range(0, 10).Select(i =>
            {
                return new
                {
                    Name = "TheApp_" + i,
                    id = i,
                };
            }));
        }
        public string getAllProjects()
        {
            return
            JsonConvert.SerializeObject(Enumerable.Range(0, 10).Select(i =>
            {
                return new
                {
                    Name = "Project_" + i,
                    id = i,
                };
            }));
        }
        public string GetTotalUsersInfo()
        {
            return
            JsonConvert.SerializeObject(
               new
               {
                   TotalUsers = rand.Next(20),
                   msg = "The message_"+ rand.Next(100),
               });
        }
    }
}
