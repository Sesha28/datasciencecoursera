﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TheFamily.Controllers
{
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Authentication.Cookies;
    using System.Security.Claims;

    public class AuthController : Controller
    {
        /// <summary>
        /// url : /Auth/Index
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// url :/Auth/LogIn
        /// </summary>
        /// <returns></returns>
        public IActionResult Login()
        {
            String uName = Request.Form["username"];
            String pwd = Request.Form["pwd"];
            //var claims = new[] { new Claim(ClaimTypes.Name, uName), new Claim(ClaimTypes.Role, "SomeRoleName") };
            //var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            //HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

            var userClaims = new List<Claim>()
            {
                    new Claim(ClaimTypes.Name, uName),
                    //new Claim(ClaimTypes.Email, "anet@test.com"),
            };

            var YourIdentity = new ClaimsIdentity(userClaims, "User Identity");

            var userPrincipal = new ClaimsPrincipal(new[] { YourIdentity });
            HttpContext.SignInAsync(userPrincipal);
            return RedirectToAction("Index", "Home");
        }
        public IActionResult logoff()
        {
            HttpContext.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}
