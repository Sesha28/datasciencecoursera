﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TheFamily.Models;

namespace TheFamily.Controllers
{
    [Microsoft.AspNetCore.Authorization.Authorize]
    public partial class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //HttpContext.SignOutAsync();
            return View();
        }

        public IActionResult Users()
        {
            return View();
        }
        public IActionResult UserRoles()
        {
            return View();
        }
        /// <summary>
        /// url :/Home/RightViewer
        /// </summary>
        /// <returns></returns>
        public IActionResult RightViewer()
        {
            //return View();
            ViewData["Title"] = "RIGHT Viewer";
            return PartialView();
        }
        public IActionResult LogIn()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
