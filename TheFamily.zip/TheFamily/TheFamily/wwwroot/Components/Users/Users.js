﻿class UsersComp {
    static users = null;
    constructor() {
        this.table = null;
        this.html = "<td><i  class='fas fa-trash' style='cursor:pointer' ></i></td>";
        this.link = "<a zora href = '_HREF_' class='mr-2'>_TEXT_</a>";
        this.tag = "Users";
    }
    start_action() {
        if (UsersComp.users == null) {
            $.ajax({ url: config.contextPath + "/Home/GetStudents", context: this })
                .done(function (jData) {
                    let jd = JSON.parse(jData);
                    jd.unshift({ "Name": "You Name", "Age": "ID", "Apps": "Registered Apps", "Projects": "Projects" });
                    this.Process(jd, this.tag);
                });
        }
        else { this.Process(UsersComp.users); }
    }
    Process(jd) {
        UsersComp.users = jd;
        let ttr = new TemplateRenderer(jd, this.tag, "/Components/Generic/Table.html");
        let that = this;
        ttr.start_action().then(function (what) { that.render(that.tag); });
    }
    render(tag) {
        this.table = $($(tag).find("Table").toArray()[0]);//table.attr("id", "ringa");
        this.table.find("tbody tr").click(this.Click_Row);
        let that = this;
        $.each(this.table.find("tbody tr").find("td:last"), function (index, item) {
            let text = $(item).text(); //$(item).html($(item).text().replace(/,/g, "&nbsp;,&nbsp;"));
            $(item).empty();
            text.split(',').forEach(str => {
                let html = that.link.replace('_HREF_', BasicAction.mapApp[str]).replace('_TEXT_', str);
                $(item).append(html);
            });
        });
        //this.table.find("tr").toArray().forEach((row, index) => {
        //    let html = this.html;
        //    $(html).appendTo(row);//.data("josh", that.jd[index]);
        //});
    }
    Click_Row(e) {
        //alert("gotcha\n" + $(e.target).closest("tr").attr("rowdata"));
        BasicAction.selectedName = JSON.parse($(e.target).closest("tr").attr("rowdata"));
        NavComponent.navigate(config.contextPath + "/Home/RightViewer", Math.random() * 1000, true);
    }
    doDelete(row) {
        alert("Labamba\n" + JSON.stringify(this.jd) + "\n" + JSON.stringify(row));
        this.jd.splice(_.findIndex(this.jd, row), 1);
        this.render();
    }
}