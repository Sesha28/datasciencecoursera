﻿class TotalUsers {
    static count = 0;
    constructor(tag, obj) {
        if (tag === undefined) this.tag = "TotalUsers";
        else this.tag = tag;
        this.s = Math.ceil(Math.random() * 20);
        this.obj = obj;
        this.template = `<div class="container text-center dashItem">
                            <div class="row">
                                <div class="col">
                                    <h3 id="tu">Total users : 20</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <h4 id="zil">Total users : 20</h4>
                                    <button id="sil" class="btn btn-warning" >Click</button>
                                </div>
                            </div>
                        </div>`;
    }
    getObject() { return "Labamba" }
    start_action() {
        $.ajax({ url: "/Home/GetTotalUsersInfo", cache: false, context: this })
            .done(function (jData) {
                this.jd = JSON.parse(jData);
                this.jd.obj = this.obj;
                this.jd.id = this.id = TotalUsers.count++;
                this.tr = new TemplateRenderer(this.jd, this.tag, config.contextPath + "/Components/Admin/TotalUsers/TotalUsers.html");
                //this.tr = new TemplateRenderer(this.jd, this.tag, config.contextPath + "/Components/Admin/TotalUsers/TotalUsers.html", this.template);
                let that = this;
                this.tr.start_action().then((what) => that.ProcessHTML(what));
            });
    }
    ProcessHTML(what) {
        //$("#zil").html(this.jd.msg);
        //$("#tu").html("Total users : " + this.jd.TotalUsers);
        $("#zil" + this.id).click((e) => this.ClickMe(e));
    }
    ClickMe(e) {
        alert("Labamba\n" + this.s);
    }
    LureMe(e, jd) {
        alert("In Lure me\n" + jd);
    }
}