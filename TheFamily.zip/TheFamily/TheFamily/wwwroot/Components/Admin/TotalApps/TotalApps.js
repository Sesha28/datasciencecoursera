﻿var TotalApps = {
    count: 0,
    //tr: null,jd:null, tag:null,rnd:null,
    start_action: function (tag, instanceName) {
        this.rnd = Math.floor(Math.random() * 100);
        this.obj = instanceName;
        if (tag == undefined) tag = "TotalApps";
        this.tag = tag;
        $.ajax({ url: "/Home/GetTotalUsersInfo", cache: false, context: this })
            .done(function (jData) {
                this.jd = JSON.parse(jData);
                this.jd.id = this.id = TotalApps.count++;
                this.jd.obj = this.obj;
                this.tr = new TemplateRenderer(this.jd, this.tag, config.contextPath + "/Components/Admin/TotalApps/TotalApps.html");
                let that = this;
                this.tr.start_action().then((what) => that.ProcessHTML(what));
            });
    },
    ProcessHTML(what) {
        $("#parishad_" + this.id).click((event) => this.Click_Parshad(event));
    },
    Click_but: function (e) {
        alert("In Click But\n" + this.id + " , " + this.rnd);
    },
    Click_Parshad(event) {
        alert("In Click Parishad\n" + this.id + " , " + this.rnd);
    }
}; 