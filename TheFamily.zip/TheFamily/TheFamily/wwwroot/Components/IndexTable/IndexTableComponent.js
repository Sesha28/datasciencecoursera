﻿class IndComponentEditable {
    constructor(objVariableName, jid) {
        this.jid = jid;
        this.jd = null;
        this.ajaxURL = "/Home/GetStudents";
        this.html = "<td><i  class='fas fa-trash' style='cursor:pointer' onclick='_OBJ_.doDelete(_DATA_)' ></i></td>";
        this.curObj = objVariableName;
    }
    doDelete(row) {
        alert("Labamba\n" + JSON.stringify(this.jd) + "\n" + JSON.stringify(row));
        this.jd.splice(_.findIndex(this.jd, row), 1);
        this.render();
    }
    start_action() {
        //get data
        $.ajax({ context: this, url: config.contextPath + this.ajaxURL }).done(function (jData) {
            this.jd = JSON.parse(jData);
            this.render();
        });
    }
    render() {
        let that = this;
        new TemplateRenderer(that.jd, that.jid, "/Components/Generic/Rows.html")
            .start_action().then(function (whatHappened) {
                //alert(whatHappened);
                $(that.jid).children("tr").toArray().forEach((row, index) => {
                    let html = that.html;
                    html = html.replace('_OBJ_', that.curObj).replace('_DATA_', JSON.stringify(that.jd[index]));
                    $(html).appendTo(row).data("josh", that.jd[index]);
                });
            });
    }
}
