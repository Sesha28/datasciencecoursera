﻿/////////////////////////////////////////////////////////////////////
/// This class has be at a global scope like in the <head></head>
///
/////////////////////////////////////////////////////////////////////
class TemplateRenderer {
    static templates = {}
    constructor(jData, tagOrJID, templatePath, HTMLTemplate) {
        this.data = jData;
        this.tagOrJID = tagOrJID;
        this.templatePath = templatePath;
        if (HTMLTemplate === undefined) return;
        TemplateRenderer.templates[this.templatePath] = HTMLTemplate;
    }
    start_action() {
        let that = this;
        if (TemplateRenderer.templates[this.templatePath] === undefined) {
            return new Promise(function (resolve, reject) {
                $.ajax({ context: that, cache: false, url: config.contextPath + that.templatePath, })
                    .done(function (htmlTemplate) {
                        TemplateRenderer.templates[this.templatePath] = htmlTemplate;
                        this.render();
                        resolve("Template NOT IN cache");
                    })
                    .fail(function (xhr, status, error) { reject(xhr, status, error); });
            });
        }
        else {
            this.render();
            return new Promise(function (resolve, reject) {
                resolve("Template in cache");
            });
        }
    }
    render() {
        let bulletsCompiled = _.template(TemplateRenderer.templates[this.templatePath]);
        let html = bulletsCompiled({ theList: this.data });
        $(this.tagOrJID).html(html);
    }
}