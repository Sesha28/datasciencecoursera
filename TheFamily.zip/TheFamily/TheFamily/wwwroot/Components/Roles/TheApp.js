﻿class TheOtherApp {
    static count = 0;
    constructor(tag, instanceName , data) {
        if (tag === undefined) this.tag = "TheOtherApp";
        else this.tag = tag;
        this.data = data;
        this.s = Math.ceil(Math.random() * 20);
        this.obj = instanceName;        
    }
    start_action(jData) {
        this.jd = jData;
        this.tr = new TemplateRenderer(this.data, this.tag, config.contextPath + "/Components/Roles/TheApp.html");
        let that = this;
        this.tr.start_action().then((what) => that.ProcessHTML(what));
    }
    ProcessHTML(what) {
        //$("#zil").html(this.jd.msg);
        //$("#tu").html("Total users : " + this.jd.TotalUsers);
        //$("#zil" + this.id).click((e) => this.ClickMe(e));
    }
}