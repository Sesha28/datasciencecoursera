﻿var Sahil = {
    start_action: function (tagorJID , theObj ) {
        if (tagorJID === undefined) tagorJID = "Sahil";
        $.ajax({ url: "/Home/GetStudents" })
            .done(function (students) {
                let MyList = JSON.parse(students);
                $.ajax({
                    url: "/Templates/Table.html", context: this,
                }).done(function (jData) {
                    compiled = _.template(jData);
                    retval = compiled({ theList: MyList, TheObject: theObj });
                    $(tagorJID).html(retval);
                });
            });        
    },
    Click_button: function (e) {
        alert("In click of button")
    }
}