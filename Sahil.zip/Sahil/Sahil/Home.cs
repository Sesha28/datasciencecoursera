﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sahil
{
    class Home
    {
        public string Index(string hi)
        {
            return hi + "_Hello";
        }
    }
}
