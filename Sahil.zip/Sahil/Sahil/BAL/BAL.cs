﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    using Utils;
    using DAL;
    //using Models;
    using Newtonsoft.Json;
    using System.Data;

    class BAL
    {
        //https://medium.com/hackernoon/how-to-query-jsonb-beginner-sheet-cheat-4da3aa5082a3
        //https://www.postgresql.org/docs/9.4/functions-json.html#FUNCTIONS-JSONB-OP-TABLE
        static string RSTR() => System.IO.Path.GetRandomFileName().Replace(".", "").Substring(0, 8);
        //public static void InsertStatement(int numRecordsToBeInserted = 20)
        //{
        //    string sqlCount = AllSQLStatements.sqlCount_employee;
        //    string count = DataAccessLayer.ExecuteScalar(sqlCount);
        //    int Count = 100; int.TryParse(count, out Count);
        //    try
        //    {
        //        for (int i = Count; i < Count + numRecordsToBeInserted; ++i)
        //        {
        //            string sql = AllSQLStatements.insertStatement_employee;
        //            Student s = new Student
        //            {
        //                Age = 10 + i,
        //                Address = "Address_" + RSTR() + i
        //            };
        //            sql = sql.Replace("_NAME_", "Taniya_" + RSTR()).Replace("_INFO_", JsonConvert.SerializeObject(s));
        //            int retval = DataAccessLayer.InsertSQL(sql);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ProcessException(), "OOPS!!!!");
        //    }
        //    MessageBox.Show("Done", "Operation completed");
        //}
        //public static void InsertStatementJSONB(int numRecordsToBeInserted = 20)
        //{
        //    string sqlCount = AllSQLStatements.sqlCount_emp_details;
        //    string count = DataAccessLayer.ExecuteScalar(sqlCount);
        //    int Count = 100; int.TryParse(count, out Count);
        //    try
        //    {
        //        for (int i = Count; i < Count + numRecordsToBeInserted; ++i)
        //        {
        //            string sql = AllSQLStatements.insertStatement_emp_details;
        //            Emp_details s = new Emp_details
        //            {
        //                Salary = 1000 + i,
        //                LastName = "Last_" + RSTR() + i
        //            };
        //            sql = sql.Replace("_DETAILS_", JsonConvert.SerializeObject(s));
        //            int retval = DataAccessLayer.InsertSQL(sql);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.ProcessException(), "OOPS!!!!");
        //    }
        //    MessageBox.Show("Done", "Operation completed");
        //}
        //public static void UpdateStatement()
        //{
        //    string sqlCount = AllSQLStatements.sqlCount_employee;
        //    string count = DataAccessLayer.ExecuteScalar(sqlCount);
        //    int Count = -100;
        //    if (!int.TryParse(count, out Count))
        //    {
        //        MessageBox.Show("No records to update", "What a dumbo u r");
        //        return;
        //    }
        //    if (Count < 20)
        //    {
        //        MessageBox.Show("Not Enough records to update\n I need more than 20 records\nFound only " + Count + " records", "What a dumbo u r");
        //        return;
        //    }
        //    int i = Count - 5;
        //    for (; i < Count; ++i)
        //    {
        //        string sql = AllSQLStatements.sqlUpdate;
        //        Student s = new Student
        //        {
        //            Age = (i + 100),
        //            Address = "Baroda_" + RSTR()
        //        };
        //        string jData = JsonConvert.SerializeObject(s);
        //        sql = sql.Replace("_ID_", i.ToString()).Replace("_INFO_", jData);
        //        try
        //        {
        //            var retVal = DataAccessLayer.ExecuteNonQuery(sql, null);
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.ProcessException());
        //        }
        //    }
        //    MessageBox.Show("Done", "Operation completed");
        //}
        public static DataTable SelectStatementVarioustypes()
        {
            DataTable dt = null;
            string sql = "SELECT * from microsoft.employee";
            //sql = "SELECT id, name, info  FROM microsoft.employee where info->> 'Age' < '0'  order by id;";
            //sql = "SELECT id, name, info  FROM microsoft.employee where id = @id  order by id;"; var param = new { @id = 1, }; dt = DataAccessLayer.GetDataTable(sql, param);
            //sql = "SELECT id, name, info  FROM microsoft.employee where info->> 'Age' < '@Age'  order by id;"; var param = new { @Age = 0, }; dt = DataAccessLayer.GetDataTable(sql, param);
            //sql = "SELECT id, name, info->'Address' as Address  FROM microsoft.employee ";
            sql = "SELECT * FROM microsoft.employee where info->>'Address' LIKE '%Address_4%';";
            //sql = "SELECT info FROM microsoft.employee where info->>'Address' LIKE '%Address_4%';";
            //sql = "SELECT id, name, json_to_record(info) as sala FROM microsoft.employee ";
            try
            {
                sql = "SELECT * FROM microsoft.employee where info->>'Address' LIKE @Address;"; var param = new { @Address = "%Address_4%" }; dt = DataAccessLayer.GetDataTable(sql, param);
                //sql = "SELECT * from microsoft.employee where name = 'Taniya_6'";
                //dt = DataAccessLayer.GetDataTable(sql, null);

                //sql = "SELECT * from microsoft.employee where name = @name";var param = new { @name = "Taniya_6" };dt = DataAccessLayer.GetDataTable(sql, param);
                var sala = string.Join(",", dt.AsEnumerable().Select(dr => dr[0].ToString()).ToArray());
                string str = JsonConvert.SerializeObject(dt, Formatting.Indented);
                //var bala = dt.AsEnumerable().Select(dr => dr["info"]).ToArray();
                //var kala = JsonConvert.SerializeObject(bala);
                //var dic = dt.AsEnumerable().ToDictionary<DataRow, string, object>(row => row.Field<string>(0), row => row.Field<object>(0));
                //string sLal = JsonConvert.SerializeObject(dic);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ProcessException());
            }
            MessageBox.Show("Done", "Operation completed");
            return dt;
        }
    }
    public class MessageBox
    {
        public static void Show(params string[] str)
        {
            foreach (string ss in str) Console.WriteLine(ss);
        }
    }
}
