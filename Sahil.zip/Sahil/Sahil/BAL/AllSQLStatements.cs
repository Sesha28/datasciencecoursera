﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL
{
    class AllSQLStatements
    {
        /// <summary>
        /// '_NAME_' , '_INFO_'
        /// </summary>
        public static readonly string insertStatement_employee = "INSERT INTO microsoft.employee (name,info) VALUES('_NAME_' , '_INFO_')";
        public static readonly string sqlCount_employee = "SELECT count(*)   FROM microsoft.employee ";
        public static readonly string sqlCount_emp_details = "SELECT count(*)   FROM microsoft.emp_details ";
        /// <summary>
        /// _INFO_ , _ID_
        /// </summary>
        public static readonly string sqlUpdate = "UPDATE microsoft.employee  SET info = '_INFO_'    WHERE id = _ID_";
        /// <summary>
        /// _DETAILS_
        /// </summary>
        public static readonly string insertStatement_emp_details = "INSERT INTO microsoft.emp_details (details) VALUES('_DETAILS_')";

        public static readonly string createIndex = "CREATE INDEX info_name_index    ON microsoft.employee USING btree    ((info->>'Address'));";
    }
}
