﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheClases
{
    public partial class Work
    {
        public String gotoOffice()
        {
            return "Going to office";
        }
    }
}
