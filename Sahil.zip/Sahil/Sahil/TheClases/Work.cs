﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheClases
{
    public partial class Work
    {
        public Work()
        {

        }
        public static String WhatWork()
        {
            return "Working in ALSTOM";
        }
        public string Hello()
        {
            return "hello";
        }
        public string Hello(int j)
        {
            return "hello " + j;
        }
    }
}
