﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utils
{
    using Sahil;
    using System.Linq;
    using TheClases;

    public static class MyExtension
    {
        public static string ExtensionMethod(this Work w, int j)
        {
            return "In Exntension method_" + j.ToString();
        }
        public static string ExtendString(this String str, int j)
        {
            return str + "_" + j.ToString();
        }
        public static string ProcessException(this Exception ex)
        {
            StringBuilder strBuild = new StringBuilder(5000);
            Exception inner = ex;
            Enumerable.Range(0, 30).All(x =>
            {
                if (x == 0) strBuild.Append("########## Exception begin on thread id :  @ :" + DateTime.Now.ToString() + " ##########\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                strBuild.Append("Message : " + inner.Message + "\nStack Trace : " + inner.StackTrace + "\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                inner = inner.InnerException;
                if (inner == null)
                {
                    strBuild.Append("########## Exception End on thread id :  @ :" + DateTime.Now.ToString() + " ##########\n\n");
                    return false;
                }
                return true;
            });
            return strBuild.ToString();
        }
    }
}
