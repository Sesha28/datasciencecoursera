﻿using System;

namespace Sahil
{
    using Model;
    using Newtonsoft.Json;
    using Npgsql;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using TheClases;
    using Utils;
    using BAL;
    struct Lal
    {
        public int id { get; set; }
    }
    class Program
    {
        //public delegate void _DoLinQ_();

        static void Main(string[] args)
        {
            //doLinQ();
            //_DoLinQ_ dl = doLinQ;
            //Action dl= doLinQ;
            //dl();           
            //string conArtist = "Host=localhost;Username=postgres;Password=root@123;Database=mycompany;";// Pooling=True;MinimumPoolSize=10;maximumpoolsize=50;";
            //String sql = "SELECT id, name, info FROM microsoft.employee";
            //From front end get data and pack it in Student
            //BAL.SelectStatementVarioustypes(Student s);
            BAL.SelectStatementVarioustypes();

        }
        static void DoSomething()
        {

            string url = "Home/Index";
            var splitEnds = url.Split('/');
            Type sType = Assembly.GetExecutingAssembly().GetTypes().Where(tpe => tpe.Name == splitEnds[0]).FirstOrDefault();
            var controller = Activator.CreateInstance(sType);

            MethodInfo mInfo = sType.GetMethod(splitEnds[1], BindingFlags.Public | BindingFlags.Instance);
            String retVal = (String)mInfo.Invoke(controller, new[] { "Howz life" });
        }
        static void doLinQ()
        {
            List<Student> lsd = new List<Student>();
            for (int i = 0; i < 10; ++i)
            {
                var st = new Student
                {
                    Name = "Sahil_" + i,
                    Age = i
                };
                lsd.Add(st);
            }
            var evenSts = lsd.Where(st => st.Age % 2 == 0).ToList();
            var evenStsComples = lsd.Where(st =>
            {
                var newAge = st.Age;
                if (newAge > 5 && newAge % 2 == 0) return true;
                else return false;
            }).ToList();
            var evenAges = lsd.Where(st => st.Age % 2 == 0).Select(st => st.Age).ToList();
        }
        static void reflect()
        {
            var ts = Assembly.GetExecutingAssembly().GetTypes();
            var tpe = typeof(Student);
            Student s = Activator.CreateInstance<Student>();
        }
        static void func_2()
        {
            Work w = new Work();
            Console.WriteLine(w.gotoOffice());
            Console.WriteLine(w.Hello(21));
            Work.WhatWork();
            Console.WriteLine(w.ExtensionMethod(23));
        }
        static void func_1()
        {
            Student s = new Student();
            s.Name = "Sahil".ExtendString(21);
            s.Age = 21;

            List<Student> lsd = new List<Student>();
            for (int i = 0; i < 10; ++i)
            {
                var st = new Student
                {
                    Name = "Sahil_" + i,
                    Age = i * 2
                };
                lsd.Add(st);
            }
            String str = JsonConvert.SerializeObject(lsd);
            String ss = File.ReadAllText(@"1.txt");
            var lsd1 = JsonConvert.DeserializeObject<List<Student>>(ss);

            Console.WriteLine("Hello World!\n" + JsonConvert.SerializeObject(s, Formatting.Indented));
            Console.WriteLine(JsonConvert.SerializeObject(lsd1));
        }

    }
}
